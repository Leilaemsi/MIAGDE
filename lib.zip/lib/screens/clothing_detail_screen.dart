import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/clothing_model.dart';
import '../models/user_model.dart';

class ClothingDetailScreen extends StatelessWidget {
  final ClothingModel clothing;
  final UserModel user;

  const ClothingDetailScreen({
    Key? key,
    required this.clothing,
    required this.user,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(clothing.title),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.memory(
              base64Decode(clothing.image),
              fit: BoxFit.cover,
              width: double.infinity,
              height: 250,
            ),
            SizedBox(height: 16),
            Text(clothing.title,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Catégorie: ${clothing.category}'),
            Text('Taille: ${clothing.size}'),
            Text('Marque: ${clothing.brand}'),
            Text('Prix: ${clothing.price} €'),
            SizedBox(height: 16),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Retour'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    // Logic to add item to user's "Panier" in Firestore
                    await addToPanier(context);
                  },
                  child: Text('Ajouter au panier'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> addToPanier(BuildContext context) async {
    try {
      // Reference to the "Utilisateurs" collection in Firestore
      CollectionReference users =
          FirebaseFirestore.instance.collection('Utilisateurs');

      // Query the user by their login (assuming login is unique)
      QuerySnapshot querySnapshot =
          await users.where('login', isEqualTo: user.login).get();

      if (querySnapshot.docs.isNotEmpty) {
        // Get the document for the user
        DocumentSnapshot userDoc = querySnapshot.docs.first;

        // Update the "Panier" field by adding the selected clothing item
        await users.doc(userDoc.id).update({
          'Panier': FieldValue.arrayUnion([
            {
              'imageUrl': clothing.image,
              'prix': clothing.price,
              'taille': clothing.size,
              'titre': clothing.title,
            }
          ])
        });

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Produit ajouté au panier!')),
        );
      } else {
        // Show error if user not found
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Utilisateur non trouvé!')),
        );
      }
    } catch (e) {
      print('Erreur: $e');
      // Show error message if something goes wrong
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur lors de l\'ajout au panier!')),
      );
    }
  }
}
