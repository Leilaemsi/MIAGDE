import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/clothing_service.dart';
import 'HomeScreen.dart';

class CartScreen extends StatefulWidget {
  final UserModel user;

  const CartScreen({Key? key, required this.user}) : super(key: key);

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final ClothingService _clothingService = ClothingService();

  @override
  Widget build(BuildContext context) {
    double total = widget.user.panier.fold(0, (sum, item) => sum + item.prix);

    return Scaffold(
      appBar: AppBar(
        title: Text('Mon Panier'),
        automaticallyImplyLeading: false,
      ),
      body: widget.user.panier.isEmpty
          ? Center(child: Text('Le panier est vide.'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: widget.user.panier.length,
                    itemBuilder: (context, index) {
                      final item = widget.user.panier[index];

                      // Décodage de l'image base64
                      String base64Image = item.imageUrl;
                      Uint8List bytes = base64Decode(base64Image);

                      return ListTile(
                        leading: Image.memory(
                          bytes,
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        ),
                        title: Text(item.titre),
                        subtitle: Text(
                            'Taille: ${item.taille}\nPrix: ${item.prix} €'),
                        trailing: IconButton(
                          icon: Icon(Icons.clear, color: Colors.red),
                          onPressed: () async {
                            // Supprimer l'élément du panier
                            setState(() {
                              widget.user.panier.removeAt(index);
                            });

                            // Supprimer du Firestore
                            await _clothingService.deleteClothing(item.id);
                            // Afficher un message de succès
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text(
                                      '${item.titre} supprimé du panier.')),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Total: ${total.toStringAsFixed(2)} €',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.shop), label: 'Acheter'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Panier'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
        currentIndex: 1,
        onTap: (index) {
          if (index == 0) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => HomeScreen(user: widget.user)),
            );
          }
        },
      ),
    );
  }
}
