import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/clothing_model.dart';

class ClothingService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<List<ClothingModel>> fetchClothingItems() async {
    try {
      final QuerySnapshot result = await _db.collection('Vetements').get();

      // Logging data for debugging
      for (var doc in result.docs) {
        final data = doc.data() as Map<String, dynamic>;
        print(data);

        // Logging each key-value pair
        data.forEach((key, value) {
          print("Key: '$key', Value: '$value', Type: ${value.runtimeType}");
        });
      }

      // Creating a list of ClothingModel using fromDocument
      final List<ClothingModel> clothingItems = result.docs.map((doc) {
        return ClothingModel.fromDocument(doc); // Use fromDocument here
      }).toList();

      return clothingItems;
    } catch (e) {
      print("Error fetching clothing items: $e");
      return [];
    }
  }

  // Method to display or process clothingItems if needed
  void afficherClothingItems(List<ClothingModel> clothingItems) {
    for (var item in clothingItems) {
      print(
          item); // Adjust according to your ClothingModel's toString implementation
    }
  }

  Future<void> addClothing(ClothingModel clothing) async {
    try {
      await _db.collection('Vetements').add(clothing.toMap());
    } catch (e) {
      print("Error adding clothing: $e");
      throw e;
    }
  }

  Future<void> deleteClothing(String clothingId) async {
    try {
      print("LEILA $clothingId");
      await _db.collection('Vetements').doc(clothingId).delete();
    } catch (e) {
      print("Error deleting clothing: $e");
      throw e;
    }
  }
}
