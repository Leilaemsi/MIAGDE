class CartItemModel {
  final String id; // Ajout de l'ID
  final String imageUrl;
  final String titre;
  final String taille;
  final double prix;

  CartItemModel({
    required this.id, // Inclure l'ID dans le constructeur
    required this.imageUrl,
    required this.titre,
    required this.taille,
    required this.prix,
  });

  factory CartItemModel.fromMap(Map<String, dynamic> map) {
    return CartItemModel(
      id: map['id'] ?? '', // Récupérer l'ID à partir de la map
      imageUrl: map['imageUrl'] ?? '',
      titre: map['titre'] ?? '',
      taille: map['taille'] ?? '',
      prix: (map['prix'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id, // Inclure l'ID dans la map
      'imageUrl': imageUrl,
      'titre': titre,
      'taille': taille,
      'prix': prix,
    };
  }
}
