import 'dart:convert'; // Pour le décodage base64
import 'dart:typed_data'; // Pour Uint8List
import 'package:flutter/material.dart';
import '../services/clothing_service.dart';
import '../models/clothing_model.dart';
import '../models/user_model.dart';
import 'clothing_detail_screen.dart';
import 'cart_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  final UserModel user;

  const HomeScreen({Key? key, required this.user}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<ClothingModel>> clothingItems;

  @override
  void initState() {
    super.initState();
    clothingItems = ClothingService().fetchClothingItems();
    print("Fetching clothing items: $clothingItems");
    print("Utilisateur connecté: "
        "Login: ${widget.user.login}, "
        "Anniversaire: ${widget.user.anniversaire}, "
        "Adresse: ${widget.user.adresse}, "
        "Code Postal: ${widget.user.codePostal}, "
        "Ville: ${widget.user.ville},");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vêtements'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Center(
              child: Text(widget.user.login),
            ),
          ),
        ],
      ),
      body: FutureBuilder<List<ClothingModel>>(
        future: clothingItems,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Erreur: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Aucun vêtement trouvé.'));
          }

          final items = snapshot.data!;

          // Debug: Print retrieved clothing items
          print("Vêtements récupérés:");
          items.forEach((clothing) {
            print(
                "Titre: ${clothing.title}, Taille: ${clothing.size}, Prix: ${clothing.price} €");
          });

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final clothing = items[index];

              // Décodage de l'image
              String base64Image = clothing.image;
              Uint8List bytes = base64Decode(base64Image);

              return ListTile(
                leading: GestureDetector(
                  onTap: () {
                    // Naviguer vers l'écran de détails
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ClothingDetailScreen(
                          clothing: clothing,
                          user: widget.user,
                        ),
                      ),
                    );
                  },
                  child: Image.memory(
                    bytes,
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                ),
                title: Text(clothing.title),
                subtitle: Text(
                    'Taille: ${clothing.size} - Prix: ${clothing.price} €'),
                onTap: () {
                  // Naviguer vers l'écran de détails
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ClothingDetailScreen(
                        clothing: clothing,
                        user: widget.user,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.shop), label: 'Acheter'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Panier'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
        currentIndex: 0,
        onTap: (index) {
          if (index == 1) {
            // Si l'utilisateur sélectionne l'onglet "Panier"
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CartScreen(user: widget.user),
              ),
            );
          } else if (index == 2) {
            // Si l'utilisateur sélectionne l'onglet "Profil"
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfileScreen(user: widget.user),
              ),
            );
          }
        },
      ),
    );
  }
}
