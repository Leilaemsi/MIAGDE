import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:tp2/screens/HomeScreen.dart';
import '../models/clothing_model.dart';
import '../models/user_model.dart';
import '../models/cart_item_model.dart';
import 'cart_screen.dart';
import 'profile_screen.dart';

class ClothingDetailScreen extends StatefulWidget {
  final ClothingModel clothing;
  final UserModel user;

  const ClothingDetailScreen({
    Key? key,
    required this.clothing,
    required this.user,
  }) : super(key: key);

  @override
  _ClothingDetailScreenState createState() => _ClothingDetailScreenState();
}

class _ClothingDetailScreenState extends State<ClothingDetailScreen> {
  int _currentIndex = 0; // Track the current index for the BottomNavigationBar

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.clothing.title),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.memory(
              base64Decode(widget.clothing.image),
              fit: BoxFit.cover,
              width: double.infinity,
              height: 250,
            ),
            SizedBox(height: 16),
            Text(widget.clothing.title,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Catégorie: ${widget.clothing.category}'),
            Text('Taille: ${widget.clothing.size}'),
            Text('Marque: ${widget.clothing.brand}'),
            Text('Prix: ${widget.clothing.price} €'),
            SizedBox(height: 16),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Retour'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await addToPanier(context);
                  },
                  child: Text('Ajouter au panier'),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.shop), label: 'Acheter'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Panier'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });

          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CartScreen(user: widget.user),
              ),
            );
          } else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfileScreen(user: widget.user),
              ),
            );
          } else if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomeScreen(user: widget.user),
              ),
            );
          }
        },
      ),
    );
  }

  int getPanierLength() {
    return widget.user.panier.length; // Retourne la longueur actuelle du panier
  }

  Future<void> addToPanier(BuildContext context) async {
    try {
      CollectionReference users =
          FirebaseFirestore.instance.collection('Utilisateurs');

      QuerySnapshot querySnapshot =
          await users.where('login', isEqualTo: widget.user.login).get();

      if (querySnapshot.docs.isNotEmpty) {
        DocumentSnapshot userDoc = querySnapshot.docs.first;
        var userData = userDoc.data() as Map<String, dynamic>;
        List<dynamic> panier = userData['Panier'] ?? [];

        // Calculate a unique ID for the new item
        int clothingId = panier.length;

        // Create a new CartItemModel
        CartItemModel newItem = CartItemModel(
          id: clothingId,
          imageUrl: widget.clothing.image,
          prix: widget.clothing.price,
          taille: widget.clothing.size,
          titre: widget.clothing.title,
        );

        // Add the new item to Firestore
        await users.doc(userDoc.id).update({
          'Panier': FieldValue.arrayUnion([newItem.toMap()])
        });

        // Add the item to the user's local panier
        setState(() {
          widget.user.panier.add(newItem);
        });

        // Display success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Produit ajouté au panier!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Utilisateur non trouvé!')),
        );
      }
    } catch (e) {
      print('Erreur: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur lors de l\'ajout au panier!')),
      );
    }
  }
}
